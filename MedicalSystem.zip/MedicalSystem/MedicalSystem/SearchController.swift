//
//  SearchController.swift
//  MedicalSystem
//
//  Created by Anthony Ford on 21/01/2018.
//  Copyright © 2018 Anthony Ford. All rights reserved.
//

import UIKit

class SearchController: UIViewController {
    @IBOutlet weak var NameInput: UITextField!
    @IBOutlet weak var NumberInput: UITextField!
    @IBOutlet weak var NameOutput: UILabel!
    @IBOutlet weak var NumberOutput: UILabel!
    var patientArray = [Patient]()
    @IBOutlet var noPatient: UIView!
    var currentPatientIndex: Int = -1
    
    @IBAction func SearchName(_ sender: Any) {
        var wasFound: Bool = false
        var indexFound: Int = -1
        for i in 0..<patientArray.count{
            if NameInput.text == patientArray[i].patientName{
                wasFound = true
                indexFound = i
            }
        }
        if wasFound == false{
            noPatient.isHidden = false
            NameOutput.isHidden = true
            NumberOutput.isHidden = true
            currentPatientIndex = -1
        }
        else{
            noPatient.isHidden = true
            NameOutput.isHidden = false
            NumberOutput.isHidden = false
            NameOutput.text = patientArray[indexFound].patientName
            NumberOutput.text = patientArray[indexFound].patientName
            currentPatientIndex = indexFound
        }
    }
    
    @IBAction func SearchNumber(_ sender: Any) {
    }
    
    @IBAction func ViewDetails(_ sender: Any) {
        if currentPatientIndex >= 0{
            performSegue(withIdentifier: "searchToDetails", sender: self)
        }
    }
    
    @IBAction func Return(_ sender: Any) {
        performSegue(withIdentifier: "searchToMenu", sender: self)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "searchToMenu"{
            if let destination = segue.destination as? ViewController{
                destination.patientArray = patientArray
            }
        }
        if segue.identifier == "searchToDetails"{
            if let destination = segue.destination as? DetailsController{
                destination.patientArray = patientArray
                destination.indexToShow = currentPatientIndex
            }
        }
    }

}
