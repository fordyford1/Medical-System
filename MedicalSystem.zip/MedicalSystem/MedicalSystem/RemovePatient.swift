//
//  RemovePatient.swift
//  MedicalSystem
//
//  Created by Anthony Ford on 20/01/2018.
//  Copyright © 2018 Anthony Ford. All rights reserved.
//

import UIKit

class RemovePatient: UIViewController, UITableViewDataSource, UITableViewDelegate {
    @IBOutlet weak var tableView: UITableView!
    
    var patientArray = [Patient]()
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return patientArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let Cell = UITableViewCell(style: .default, reuseIdentifier: "removePatientCell")
        Cell.textLabel?.text? = patientArray[indexPath.row].patientName + patientArray[indexPath.row].patientNumber
        return Cell
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        patientArray.remove(at: indexPath.row)
        tableView.deselectRow(at: indexPath, animated: true)
        tableView.reloadData()
    }
    @IBAction func `return`(_ sender: Any) {
        performSegue(withIdentifier: "return", sender: self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "return"{
            if let destination = segue.destination as? ViewController{
                destination.patientArray = patientArray
            }
        }
    }

}
