//
//  EditController.swift
//  MedicalSystem
//
//  Created by Anthony Ford on 21/01/2018.
//  Copyright © 2018 Anthony Ford. All rights reserved.
//

import UIKit

class EditController: UITableViewController{
    var patientArray = [Patient]()
    var indexSelected = -1
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let Cell = UITableViewCell(style: .default, reuseIdentifier: "editPatientCell")
        Cell.textLabel?.text = patientArray[indexPath.row].patientName + patientArray[indexPath.row].patientNumber
        return Cell
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return patientArray.count
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        indexSelected = indexPath.row
        performSegue(withIdentifier: "editToDetails", sender: self)
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "editToDetails"{
            if let destination = segue.destination as? DetailsController{
                destination.patientArray = patientArray
                destination.indexToShow = indexSelected
            }
        }
    }

  
}
