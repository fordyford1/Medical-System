//
//  DetailsController.swift
//  MedicalSystem
//
//  Created by Anthony Ford on 21/01/2018.
//  Copyright © 2018 Anthony Ford. All rights reserved.
//

import UIKit

class DetailsController: UIViewController {
    var patientArray = [Patient]()
    var indexToShow = -1
    
    @IBOutlet weak var patientName: UITextField!
    @IBOutlet weak var patientNumber: UILabel!
    @IBOutlet weak var doctorName: UITextField!
    @IBOutlet weak var dateOfBirth: UITextField!
    @IBOutlet weak var priority: UITextField!
    @IBOutlet weak var dateIn: UITextField!
    @IBOutlet weak var medicationName: UITextField!
    @IBOutlet weak var timesTaken: UITextField!
    @IBOutlet weak var dateTaken: UITextField!
    
    @IBAction func AddMedication(_ sender: Any) {
        var medArray = [String]()
        //adds text from fields to array, then clears them
        medArray.append(medicationName.text!)
        medArray.append(timesTaken.text!)
        medArray.append(dateTaken.text!)
        medicationName.text = ""
        timesTaken.text = ""
        dateTaken.text = ""
        //adds the array for this medication to the 2D array in the class then empties the temporary array. Chooses patient by index sent from previous view
        patientArray[indexToShow].medsArray.append(medArray)
        medArray.removeAll()
    }
    @IBAction func UpdateInfo(_ sender: Any) {
        patientArray[indexToShow].patientName = patientName.text!
        patientArray[indexToShow].patientDoctor = doctorName.text!
        patientArray[indexToShow].patientDoB = dateOfBirth.text!
        patientArray[indexToShow].patientPriority = priority.text!
        patientArray[indexToShow].patientAdmittance = dateIn.text!
        patientArray[indexToShow].updateStats()
    }
    
    
    @IBAction func ReturnToMenu(_ sender: Any) {
        performSegue(withIdentifier: "detailsToMenu", sender: self)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        patientName.text = patientArray[indexToShow].patientName
        doctorName.text = patientArray[indexToShow].patientDoctor
        dateOfBirth.text = patientArray[indexToShow].patientDoB
        priority.text = patientArray[indexToShow].patientPriority
        dateIn.text = patientArray[indexToShow].patientAdmittance
        patientNumber.text = patientArray[indexToShow].patientNumber
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "detailsToMenu"{
            if let destination = segue.destination as? ViewController{
                destination.patientArray = patientArray
            }
        }
    }
}
