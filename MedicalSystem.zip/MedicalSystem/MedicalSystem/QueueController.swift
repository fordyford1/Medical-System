//
//  QueueController.swift
//  MedicalSystem
//
//  Created by Anthony Ford on 26/01/2018.
//  Copyright © 2018 Anthony Ford. All rights reserved.
//

import UIKit

class QueueController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet weak var tableView: UITableView!
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return patientArray.count
    }
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let Cell = UITableViewCell(style: .default, reuseIdentifier: "DequeueCells")
        Cell.textLabel?.text = patientArray[indexPath.row].patientName
        return Cell
    }
    public func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 0{
            patientArray.remove(at: 0)
            tableView.reloadData()
            
        }
        else{
            let alert = UIAlertController(title: "Cant remove that", message: "Remove the first patient first", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "Default Action"), style: .default, handler: { _ in NSLog("tried to remove wrong patient")}))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    
    var patientArray = [Patient]()
    
    @IBAction func ReturnToMenu(_ sender: Any) {
        //when button is pressed, performs segue to return to menu
        performSegue(withIdentifier: "queueToMenu", sender: self)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        patientArray = mergeAndSort(array: patientArray)
        tableView.reloadData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func merge(leftArray: [Patient], rightArray: [Patient]) -> [Patient]{
        var leftIndex = 0
        var rightIndex = 0
        var orderedArray: [Patient] = []
        while leftIndex < leftArray.count && rightIndex < rightArray.count{
            if leftArray[leftIndex].patientPriority <= rightArray[rightIndex].patientPriority{
                orderedArray = orderedArray + [leftArray[leftIndex]]
                leftIndex += 1
            }
            else{
                orderedArray = orderedArray + [rightArray[rightIndex]]
                rightIndex += 1
            }
        }
        orderedArray = orderedArray + Array(leftArray[leftIndex..<leftArray.count]) + Array(rightArray[rightIndex..<leftArray.count])
        return orderedArray
    }
    func mergeAndSort(array: [Patient]) -> [Patient]{
        if array.count <= 1{
            return array
        }
        let indexToSplitArray = array.count / 2
        let leftArray = mergeAndSort(array: Array(array[0..<indexToSplitArray]))
        let rightArray = mergeAndSort(array: Array(array[indexToSplitArray..<array.count]))
        return merge(leftArray: leftArray, rightArray: rightArray)
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "queueToMenu"{
            if let destination = segue.destination as? ViewController{
                destination.patientArray = patientArray
            }
        }
    }

}
