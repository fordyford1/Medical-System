//
//  AddPatient.swift
//  MedicalSystem
//
//  Created by Anthony Ford on 16/01/2018.
//  Copyright © 2018 Anthony Ford. All rights reserved.
//

import UIKit

class AddPatient: UIViewController {
    var medsArray = [[String]]()
    var currentArray = [String]()
    var patientArray = [Patient]()
    @IBOutlet weak var NameInput: UITextField!
    @IBOutlet weak var dobInput: UITextField!
    @IBOutlet weak var dateInput: UITextField!
    @IBOutlet weak var natureInput: UITextField!
    @IBOutlet weak var doctorInput: UITextField!
    @IBOutlet weak var medicationInput: UITextField!
    @IBOutlet weak var dateTakenInput: UITextField!
    @IBOutlet weak var timesTakenInput: UITextField!
    
    @IBAction func AddMeds(_ sender: Any) {
        currentArray.append(medicationInput.text!)
        currentArray.append(timesTakenInput.text!)
        currentArray.append(dateTakenInput.text!)
        medicationInput.text = ""
        dateTakenInput.text = ""
        timesTakenInput.text = ""
        medsArray.append(currentArray)
        currentArray.removeAll()
    }
    @IBAction func AddPatient(_ sender: Any) {
        var currentPatient = Patient()
        currentPatient.patientNumber = String(patientArray.count + 1)
        currentPatient.patientName = NameInput.text!
        currentPatient.patientDoB = dobInput.text!
        currentPatient.patientDoctor = doctorInput.text!
        currentPatient.medsArray = medsArray
        currentPatient.patientAdmittance = dateInput.text!
        currentPatient.patientPriority = natureInput.text!
        currentPatient.updateStats()
        patientArray.append(currentPatient)
        performSegue(withIdentifier: "returnToMenu", sender: self)
    }
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "returnToMenu"{
            if let destination = segue.destination as? ViewController{
                destination.patientArray = patientArray
            }
        }
    }
    

}
