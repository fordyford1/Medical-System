//
//  Patient.swift
//  MedicalSystem
//
//  Created by Anthony Ford on 16/01/2018.
//  Copyright © 2018 Anthony Ford. All rights reserved.
//

import Foundation
class Patient{
    var patientDetails = [[String]]()
    var patientName = String()
    var patientNumber = String()
    var patientDoctor = String()
    var patientDoB = String()
    var patientPriority = String()
    var patientAdmittance = String()
    var medsArray = [[String]]()
    func updateStats(){
        var tempArray = [String]()
        patientDetails.removeAll()
        tempArray.append(patientName)
        tempArray.append(patientNumber)
        tempArray.append(patientDoB)
        patientDetails.append(tempArray)
        tempArray.removeAll()
        tempArray.append(patientPriority)
        tempArray.append(patientDoctor)
        tempArray.append(patientAdmittance)
        patientDetails.append(tempArray)
        tempArray.removeAll()
        for i in 0..<medsArray.count{
            tempArray = medsArray[i]
            patientDetails.append(tempArray)
            tempArray.removeAll()
        }
    }
    
}
