//
//  ViewController.swift
//  MedicalSystem
//
//  Created by Anthony Ford on 16/01/2018.
//  Copyright © 2018 Anthony Ford. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var patientArray = [Patient]()
    
    @IBAction func addPatient(_ sender: Any) {
        performSegue(withIdentifier: "addPatients", sender: self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //whenever any of the buttons are pressed, sends the patient Array to the next view.
        if segue.identifier == "addPatients"{
            if let destination = segue.destination as? AddPatient{
                destination.patientArray = patientArray
            }
        }
        if segue.identifier == "removePatient"{
            if let destination = segue.destination as? RemovePatient{
                destination.patientArray = patientArray
            }
        }
        if segue.identifier == "viewPatients"{
            if let destination = segue.destination as? EditController{
                destination.patientArray = patientArray
            }
        }
        if segue.identifier == "searchPatients"{
            if let destination = segue.destination as? SearchController{
                destination.patientArray = patientArray
            }
        }
        if segue.identifier == "toPatientQueue"{
            if let destination = segue.destination as? QueueController{
                destination.patientArray = patientArray
            }
        }
    }
}

